package com.concurrency.concurrent.calls;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

import org.apache.tomcat.util.json.JSONParser;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import static org.apache.logging.log4j.message.MapMessage.MapFormat.JSON;

@SpringBootApplication
public class ConcurrentRunnerApp implements CommandLineRunner {

	@Autowired
	private AsyncService asyncService;

	@Autowired
	private ConfigurableApplicationContext context;

	public static void main(String[] args) {

		SpringApplication.run(ConcurrentRunnerApp.class, args);// .close();
	}

	@Override
	public void run(String... args) throws Exception {
		Instant start = Instant.now();
		List<String> countries = new ArrayList<>();
		countries.add("india");
		countries.add("peru");
		countries.add("italy");

		List<CompletableFuture<String>> allFutures = new ArrayList<>();

		for (int i = 0; i < countries.size(); i++) {
			allFutures.add(asyncService.callMsgService(countries.get(i)));
		}

		CompletableFuture.allOf(allFutures.toArray(new CompletableFuture[0])).join();

		String finalResponse = "";
		//JSONArray jsonArray = new JSONArray(JSON);

		//JSONObject json =

		for (int i = 0; i < countries.size(); i++) {
			System.out.println("--------------------------------------");
			//System.out.println("response: " + allFutures.get(i).get().toString());
			//JSONObject obj=new JSONObject(allFutures.get(i).get().toString());
			//jsonArray.put("CountriesList" +obj);
			//obj =  allFutures.get(i).get().toString();
			finalResponse = finalResponse + allFutures.get(i).get().toString();
		}

		//System.out.println("Final Response merged : " + jsonArray.toString());
		System.out.println("Final Response merged : " + finalResponse);

		Instant finish = Instant.now();

		long timeElapsed = Duration.between(start, finish).toMillis();

		System.out.println("Total time: " + timeElapsed + " ms");

		System.exit(SpringApplication.exit(context));
	}

}
