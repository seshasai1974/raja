package com.concurrency.concurrent.calls.forkjoin;

import org.springframework.http.HttpMethod;
import org.springframework.web.client.AsyncRestTemplate;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.ForkJoinTask;
import java.util.concurrent.RecursiveTask;

public class ForkJoinMultipleRestCall extends RecursiveTask {

    private volatile String result;

    public ForkJoinMultipleRestCall(String result) {
        this.result = result;
    }

    @Override
    protected String compute() {
        String n = result;
            ForkJoinMultipleRestCall f1 = new ForkJoinMultipleRestCall("https://restcountries.com/v3.1/name/pakistan");
            ForkJoinMultipleRestCall f2 = new ForkJoinMultipleRestCall("https://restcountries.com/v3.1/name/peru");
            ForkJoinTask.invokeAll(f1, f2);
        result = f1.result+f2.result;
        return result;
    }

    private static String callRest(String url) {
        RestTemplate restTemplate = new RestTemplate();
        String result =  restTemplate.getForObject(url,String.class);
        return result;
    }


    public static void main(String[] args) {
        URI exampleURI = URI.create("https://www.stackoverflow.com");

        AsyncRestTemplate template = new AsyncRestTemplate/* specific request factory*/();
        var future1 = template.exchange(exampleURI, HttpMethod.GET, null, String.class).completable();
        var future2 = template.exchange(exampleURI, HttpMethod.GET, null, String.class).completable();
        var future3 = template.exchange(exampleURI, HttpMethod.GET, null, String.class).completable();

        CompletableFuture.allOf(future1, future2, future3).thenRun(() -> {

            
        });
    }
}